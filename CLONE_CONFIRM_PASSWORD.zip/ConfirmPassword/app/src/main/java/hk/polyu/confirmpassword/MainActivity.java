package hk.polyu.confirmpassword;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setResult(RESULT_OK);
        finish();

        /*
        Button test = findViewById(R.id.test);
        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent intent = new Intent("meizu.intent.action.CONFIRM_PASSWORD");
                // intent.putExtras(getIntent());
                // intent.setPackage("com.android.settings");

                Intent intent = new Intent("android.app.action.CONFIRM_GALLERY_PASSWORD");
                startActivityForResult(intent, 0);
            }
        });

        Button ok = findViewById(R.id.ok);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }
        });
        */
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*
        if (data != null) {
            TextView resultView = findViewById(R.id.result);
            resultView.setText(data.toString());
        }
        */

        // setResult(resultCode, data);
        // finish();
    }
}